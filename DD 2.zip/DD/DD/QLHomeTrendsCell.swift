//
//  QLHomeTrendsCell.swift
//  DD
//
//  Created by 瓦栏 on 2018/4/27.
//  Copyright © 2018年 Qingshan. All rights reserved.
//

import UIKit

let screenwidth = UIScreen.main.bounds.size.width

class QLHomeTrendsCell: UITableViewCell {
    
    var images = [String](){
        didSet{
            if images.count == 0 {
                imageBackViewHeight.constant = 0
            }
            if images.count == 1 {
                
                let height = screenwidth - 30
                
                imageBackViewHeight.constant = height
                collectionLayout.itemSize = CGSize(width: height, height: height)
                collectionLayout.minimumLineSpacing = 0
                collectionLayout.minimumInteritemSpacing = 0
                
            }
            
            if images.count == 2 {
                let height = (screenwidth - 3 - 30)/2
                imageBackViewHeight.constant = height
                collectionLayout.itemSize = CGSize(width: height, height: height)
                collectionLayout.minimumLineSpacing = 0
                collectionLayout.minimumInteritemSpacing = 3
            }
            if images.count == 3 {
                let height = (screenwidth - 6 - 30)/3
                imageBackViewHeight.constant = height
                collectionLayout.itemSize = CGSize(width: height, height: height)
                collectionLayout.minimumLineSpacing = 0
                collectionLayout.minimumInteritemSpacing = 3
            }
            if images.count == 4 {
                
                let height = (screenwidth - 6 - 30)/2
                
                imageBackViewHeight.constant = height * 2 + 3
                collectionLayout.itemSize = CGSize(width: height, height: height)
                collectionLayout.minimumLineSpacing = 3
                collectionLayout.minimumInteritemSpacing = 3
            }
            if images.count == 5 {
                
                let height = (screenwidth - 6 - 30)/3
                
                imageBackViewHeight.constant = height * 2 + 3
                
                collectionLayout.itemSize = CGSize(width: height, height: height)
                collectionLayout.minimumLineSpacing = 3
                collectionLayout.minimumInteritemSpacing = 3
            }
            if images.count == 6 {
                
                let height = (screenwidth - 6 - 30)/3
                
                imageBackViewHeight.constant = height * 2 + 3
                
                collectionLayout.itemSize = CGSize(width: height, height: height)
                collectionLayout.minimumLineSpacing = 3
                collectionLayout.minimumInteritemSpacing = 3
            }
            if images.count == 7 {
                let height = (screenwidth - 6 - 30)/3
                
                imageBackViewHeight.constant = height * 3 + 6
                
                collectionLayout.itemSize = CGSize(width: height, height: height)
                collectionLayout.minimumLineSpacing = 3
                collectionLayout.minimumInteritemSpacing = 3
            }
            if images.count == 8 {
                let height = (screenwidth - 6 - 30)/3
                
                imageBackViewHeight.constant = height * 3 + 6
                
                collectionLayout.itemSize = CGSize(width: height, height: height)
                collectionLayout.minimumLineSpacing = 3
                collectionLayout.minimumInteritemSpacing = 3
            }
            if images.count == 9 {
                let height = (screenwidth - 6 - 30)/3
                
                imageBackViewHeight.constant = height * 3 + 6
                
                collectionLayout.itemSize = CGSize(width: height, height: height)
                collectionLayout.minimumLineSpacing = 3
                collectionLayout.minimumInteritemSpacing = 3
            }
            
            collectionView.reloadData()
        }
    }

    @IBOutlet weak var headerImageView: UIImageView!{
        didSet{
            headerImageView.layer.cornerRadius = 22
            
        }
    }
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var sloganLabel: UILabel!
    @IBOutlet weak var attentionButton: UIButton!{
        didSet{
            attentionButton.layer.cornerRadius = 15
        }
    }
    @IBOutlet weak var contentLable: UILabel!
    @IBOutlet weak var imageBackViewHeight: NSLayoutConstraint!
    @IBOutlet weak var collectionView: UICollectionView!{
        didSet{
            collectionView.register(UINib.init(nibName: "WLImageCell", bundle: nil), forCellWithReuseIdentifier: "WLImageCell")
            collectionView.dataSource = self
            collectionView.delegate = self
            
        }
    }
    @IBOutlet weak var collectionLayout: UICollectionViewFlowLayout!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var favButton: UIButton!
    @IBOutlet weak var replyButton: UIButton!
    @IBOutlet weak var fwButton: UIButton!
    
    @IBAction func attentionButtonAction(_ sender: UIButton) {
        
    }
    @IBAction func favButtonAction(_ sender: UIButton) {
    }
    @IBAction func replyButtonAction(_ sender: UIButton) {
    }
    @IBAction func fwButtonAction(_ sender: UIButton) {
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

extension QLHomeTrendsCell: UICollectionViewDataSource, UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return self.images.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "WLImageCell", for: indexPath) as! WLImageCell
        let url = self.images[indexPath.item]
        
        cell.imageView.setImageWith(URL.init(string: url), placeholder: nil)
        return cell
        
    }
}
