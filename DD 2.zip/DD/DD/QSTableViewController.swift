//
//  QSTableViewController.swift
//  DD
//
//  Created by 瓦栏 on 2018/4/26.
//  Copyright © 2018年 Qingshan. All rights reserved.
//

import UIKit

class QSTableViewController: UITableViewController {

    
    let dataArr = [
        [],
        
        ["https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg"],
        
        [
         "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
         "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg"
        ],
        
        [
         "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
         "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
         "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg"
        ],
        
        [
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg"
        ],
        
        [
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg"
        ],
        
        [
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg"
        ],
        
        [
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg"
        ],
        
        [
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg"
        ],
        
        [
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg",
            "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1524808538&di=76f435ac59c559e9076c682dace288ee&src=http://imgsrc.baidu.com/imgad/pic/item/8601a18b87d6277fde06cb1b22381f30e924fcf9.jpg"
        ],
        
        ]
    
    var scollBlock: ((CGFloat) -> ())?
    var celltitle = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.rowHeight = UITableViewAutomaticDimension
        self.tableView.estimatedRowHeight = 100
        self.tableView.estimatedSectionFooterHeight = 0
        self.tableView.estimatedSectionHeaderHeight = 0
        
        self.tableView.register(UINib.init(nibName: "QLHomeTrendsCell", bundle: nil)   , forCellReuseIdentifier: "QLHomeTrendsCell")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source
    
    override func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if let scollBlock = scollBlock{
            scollBlock(scrollView.contentOffset.y)
        }
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.dataArr.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "QLHomeTrendsCell", for: indexPath) as! QLHomeTrendsCell

        cell.images = self.dataArr[indexPath.row]

        return cell
    }
 


}
