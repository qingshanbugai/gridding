//
//  WLImageCell.swift
//  DD
//
//  Created by 瓦栏 on 2018/4/27.
//  Copyright © 2018年 Qingshan. All rights reserved.
//

import UIKit

class WLImageCell: UICollectionViewCell {

    @IBOutlet weak var imageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
