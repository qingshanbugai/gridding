//
//  ViewController.swift
//  DD
//
//  Created by 瓦栏 on 2018/4/26.
//  Copyright © 2018年 Qingshan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let bannerH = CGFloat(300)
    
    lazy var scrollView = {() -> UIScrollView in
        let scroll = UIScrollView.init(frame: self.view.bounds)
        scroll.contentSize = CGSize(width: self.view.bounds.size.width, height: self.view.bounds.size.height + bannerH)
        scroll.delegate = self
        return scroll
    }()
    
    let navigationHeight = 44.0
    
    let titleArr = ["公开区","VIP区","密码区","微动态"]
    
    lazy var pageVC = { () -> VTMagicController in
        let tempmagicController = VTMagicController()
        
        tempmagicController.magicView.navigationColor = .white
        tempmagicController.magicView.sliderColor = UIColor.gray
        tempmagicController.magicView.layoutStyle = .center
        
        tempmagicController.magicView.itemSpacing = 30.0
        tempmagicController.magicView.switchStyle = .stiff
        tempmagicController.magicView.navigationHeight = CGFloat(navigationHeight)
        //        tempmagicController.magicView.needPreloading = false
        tempmagicController.magicView.dataSource = (self as VTMagicViewDataSource)
        tempmagicController.magicView.delegate = (self as VTMagicViewDelegate)
        
        //这里有个bug，在iOS11以下，magicView往下移了64，需要在viewDidAppear里晃动一下scrollview
        
        
        tempmagicController.magicView.headerHeight = bannerH
        tempmagicController.magicView.headerView.backgroundColor = .blue
        tempmagicController.magicView.isHeaderHidden = false
        
        let imageView = UIImageView.init(image: UIImage.init(named: "head"))
        imageView.frame = CGRect(x: 0, y: 0, width: self.view.bounds.size.width, height: bannerH)
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        
        tempmagicController.magicView.headerView.addSubview(imageView)
        
        return tempmagicController
        
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(self.scrollView)
        self.scrollView.addSubview(self.pageVC.magicView)
        self.pageVC.magicView.frame = CGRect(x: 0, y: 0, width: self.view.bounds.size.width, height: self.view.bounds.size.width + bannerH)
        
        self.pageVC.magicView.reloadData()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

extension ViewController: UIScrollViewDelegate{
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let y = scrollView.contentOffset.y
        print("scroll===\(y)")
        if y < 0 {
            scrollView.contentOffset.y = 0
        }else if y > bannerH{
            scrollView.contentOffset.y = bannerH
        }else{
            
        }
        
    }
}
extension ViewController: VTMagicViewDataSource{
    
    func menuTitles(for magicView: VTMagicView) -> [String] {
        
        return titleArr
    }
    
    func magicView(_ magicView: VTMagicView, menuItemAt itemIndex: UInt) -> UIButton {
        
        let itemButton = UIButton(type: .custom)
        itemButton.setTitle(titleArr[Int(itemIndex)], for: .normal)
        itemButton.setTitleColor(.gray, for: .normal)
        
        return itemButton
    }
    
    func magicView(_ magicView: VTMagicView, viewControllerAtPage pageIndex: UInt) -> UIViewController {
        
       let vc = QSTableViewController()
        
        vc.view.frame = CGRect(x: CGFloat(navigationHeight), y: 0, width: self.view.bounds.size.width, height: self.view.bounds.size.height - CGFloat(navigationHeight))
        
        vc.celltitle = "hhahah\(pageIndex)"
        
        vc.scollBlock = {y in
            print("table===\(y)")
            if y < 0 {
                self.scrollView.contentOffset.y += (y/10)
            }else if y >= self.bannerH{
                self.scrollView.contentOffset.y = self.bannerH
            }else{
                self.scrollView.contentOffset.y += (y/10)
            }
        }
        return vc
        
        
    }
    
   
    
}

extension ViewController: VTMagicViewDelegate{
    
    func magicView(_ magicView: VTMagicView, didSelectItemAt itemIndex: UInt) {
        
    }
    
}

